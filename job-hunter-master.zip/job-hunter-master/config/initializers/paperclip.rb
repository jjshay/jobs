Paperclip::Attachment.default_options[:use_timestamp] = false
